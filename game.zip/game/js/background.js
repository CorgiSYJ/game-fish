//1:创建函数 drawBackground
//2:在函数中绘制图片
function drawBackground(){
  ctx2.drawImage(bgPic,0,0,canWidth,canHeight);
} 
//3:将background.js加载index.html